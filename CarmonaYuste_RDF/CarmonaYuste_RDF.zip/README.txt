! DISCLAIMER !
Zerbitzariaren IP helbidea dinamikoa izanik, pizten den bakoitzean IP-a aldatuz doa, beraz, zeozer dela eta berrabiarazi behar bada, ezin izango da helbidea jakin, nahiz eta GraphDB 7200 portuan exekutatzen den. Hala ere, Gaizkaren zerbitzarian GraphDB exekutatzen utzi da, hurrengo helbidean:

http://192.158.29.218:7200

Named Graph URI --> http://carmonayuste.eus
